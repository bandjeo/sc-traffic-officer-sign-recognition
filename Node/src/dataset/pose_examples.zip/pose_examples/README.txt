stajaca poza 1 moze da bude i okrenuta ledjima ili ka kameri
stajaca poza 2 moze da bude okrenuta ili levo ili destno
kod zaustavi vozilo i pridji blize probaj da ne sakrijes lice sakom (kao ja) nego pomeri saku desno od svog lice (iz tvoje perspektive, koristis desnu ruku, znaci ka spolja)